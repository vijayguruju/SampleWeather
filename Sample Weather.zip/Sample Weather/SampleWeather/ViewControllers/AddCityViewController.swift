//
//  AddCityViewController.swift
//  SampleWeather
//
//  Created by Dinesh Sunder on 13/04/20.
//  Copyright © 2020 Vijay. All rights reserved.
//

import UIKit

protocol AddCityProtocol {
    func addCity(cityName:String)
}

class AddCityViewController: UIViewController {
    @IBOutlet weak var cityTxt: UITextField!
    var delegate:AddCityProtocol?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.backgroundColor = .white
    }
    
    //MARK:- Create text field and button
    func createViews(){
        
        let xPosition:CGFloat = 15
        let yPosition:CGFloat = 30
        let cityTxtField = UITextField(frame: CGRect(x: xPosition, y: yPosition, width: UIScreen.main.bounds.width - 2 * xPosition, height: 45))
        view.addSubview(cityTxtField)
        cityTxtField.borderStyle = .roundedRect
        cityTxtField.placeholder = "Enter City"
        
        
    }
    
    @IBAction func submitBtnAction(_ sender: Any) {
        if self.delegate != nil{
            
            delegate?.addCity(cityName: self.cityTxt.text!)
        }
        self.dismiss(animated: true, completion: nil)
        
    }
    

}
