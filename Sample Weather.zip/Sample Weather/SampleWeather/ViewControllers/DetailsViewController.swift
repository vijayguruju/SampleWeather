//
//  DetailsViewController.swift
//  SampleWeather
//
//  Created by Dinesh Sunder on 14/04/20.
//  Copyright © 2020 Vijay. All rights reserved.
//

import UIKit
import CoreData
class DetailsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var cityNameLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var tempLbl: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    var citiesData = NSManagedObject()

    let timesArray = ["Now","11AM","12PM","1PM","2PM","3PM","4PM","5PM","6PM","7PM","8PM","9PM","10PM","11PM","12AM","1AM","2AM","3AM","4AM","5AM","6AM","7AM","8AM","9AM"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        navigationController?.isNavigationBarHidden = false
        
        //Borders
        collectionView.layer.borderColor = UIColor.white.cgColor
        collectionView.layer.borderWidth = 0.5
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "DetailCell")
        tableView.register(UINib(nibName: "ForeCastTableViewCell", bundle: nil), forCellReuseIdentifier: "ForecastCell")
        tableView.register(UINib(nibName: "WeatherDetailsTableViewCell", bundle: nil), forCellReuseIdentifier: "WeatherDetailsCell")

    
        if let name = citiesData.value(forKey: "cityname") as? String{
            if let temp = citiesData.value(forKey: "temp") as? String{
                cityNameLbl.text = name + ", \(String(format: "%.0f", Double(temp)! - 273.15))°"
            }

        }
        if let desc = citiesData.value(forKey: "desc") as? String{
            descLbl.text = desc
        }
        
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        navigationController?.isNavigationBarHidden = true

    }
    //MARK:- TableView Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return 210
        case 1:
            return 60
        case 2:
            return 305
        default:
           return 50
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCell")!
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ForecastCell") as! ForeCastTableViewCell
            return cell
        }
        else if indexPath.section == 2{
            let cell = tableView.dequeueReusableCell(withIdentifier: "WeatherDetailsCell") as! WeatherDetailsTableViewCell
            if let sunrise = citiesData.value(forKey: "sunrise") as? String{
                cell.sunriseLbl.text = sunrise
            }
            if let sunset = citiesData.value(forKey: "sunset") as? String{
                cell.sunsetLbl.text = sunset

            }
            if let speed = citiesData.value(forKey: "wind") as? String{
                cell.windLbl.text = "\(speed) kph"
                
            }
            if let humidity = citiesData.value(forKey: "humidity") as? String{
                cell.humidityLbl.text = "\(humidity)%"
                
            }
            if let feelsLike = citiesData.value(forKey: "feelslike") as? String{
                cell.feelsLikeLbl.text = String(format: "%.0f", Double(feelsLike)! - 273.15) + "°" //converting kelving to celsius

            }
            if let pressure = citiesData.value(forKey: "pressure") as? String{
                cell.pressureLbl.text = "\(pressure) hPa"
            }
            return cell
        }
        cell.textLabel?.text = "Taday: Mostly \(self.descLbl.text ?? "")"
        cell.backgroundColor = UIColor.systemTeal
        cell.textLabel?.textColor = UIColor.white
        return cell
    }
    
    //MARK:- CollectionView Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 24
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! TimeWiseCollectionViewCell

        
        cell.timeLbl.text = timesArray[indexPath.item]
        cell.tempLbl.text = "32°"
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width , height: collectionView.frame.height)
    }

}
