//
//  ViewController.swift
//  SampleWeather
//
//  Created by Dinesh Sunder on 13/04/20.
//  Copyright © 2020 Vijay. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource, AddCityProtocol {
    @IBOutlet weak var footerView: UIView!
    
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    let apiKey = "66c3fd0cb6de2383542585703136321a"
    var citiesData = [NSManagedObject]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Register Tabeview cell
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "TableCell")
        //Get existing data if any
        do {
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Details")

           let results = try self.context.fetch(fetchRequest)
           let obtainedResults = results as! [NSManagedObject]
           self.citiesData = obtainedResults
            }catch{
                print("Error")
            }
            if citiesData.count > 0{
                self.tableView.reloadData()
            }
        //button layout
        addButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 30)
        addButton.layer.borderColor = UIColor.white.cgColor
        addButton.layer.borderWidth = 3
        addButton.layer.cornerRadius = 20
        //table footer
        tableView.tableFooterView = footerView

    }
    
   
    //MAR:- Add city button action
    @IBAction func addButtonAction(_ sender: Any) {
        
        let cityVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddCityViewController") as! AddCityViewController
        cityVC.delegate = self
        self.present(cityVC, animated: true, completion: nil)
    }
   

    //MARK:- TableView Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return citiesData.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell")!
        
        let citiDetails = citiesData[indexPath.row]
        if let name = citiDetails.value(forKey: "cityname") as? String{
            if let desc = citiDetails.value(forKey: "desc") as? String{
                if let temp = citiDetails.value(forKey: "temp") as? String{
                cell.backgroundColor = .systemTeal
                cell.textLabel?.text = "\(name), \(desc), \(String(format: "%.0f", Double(temp)! - 273.15))°" 
                cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 22)
                cell.textLabel?.textColor = .white
                }
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailsVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "DetailsViewController") as! DetailsViewController
        detailsVC.citiesData = self.citiesData[indexPath.row]
        
        self.navigationController?.show(detailsVC, sender: self)
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    //MARK:- Add city delegate method and API call
       func addCity(cityName:String){
        let url = "https://api.openweathermap.org/data/2.5/weather?q=\(cityName)&appid=66c3fd0cb6de2383542585703136321a"
           let requestUrl = URL(string: url)
           let task = URLSession.shared.dataTask(with: requestUrl! ) {(data, response, error) in

            do {
                guard let data = data else {
                    print("No Data")
                    return
                }
                guard let json = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary else {
                    print("Failed")
                    return
                }
                let statusResponse = response as? HTTPURLResponse
                let statusCode = statusResponse?.statusCode
                switch statusCode{
                case 404:
                    print(json)
                    if let msg = json.value(forKey: "message") as? String{
                        print(msg)
                    }
               
                    
                case 200:
                    
                    print(json)
                    
                    
                    let entity = NSEntityDescription.entity(forEntityName: "Details", in: self.context)
                    let detailsEntity = NSManagedObject(entity: entity!, insertInto: self.context)

                    if let cityName = json.value(forKey: "name") as? String{
                       detailsEntity.setValue(cityName, forKey: "cityname")
                       

                    }
                    //description
                    if  let weather = json.value(forKey: "weather") as? [[String:Any]]{
                        
                        for weatherData in weather{
                            if let description = weatherData["description"] as? String{
                                detailsEntity.setValue(description, forKey: "desc")
                            }
                        }
                        
                    }
                    //sunrise , sunset
                    let sysDictionary = json["sys"] as? [String: Any]
                    if let sunrise = sysDictionary!["sunrise"] as? NSNumber {

                    let sunriseDate = Date(timeIntervalSince1970: sunrise.doubleValue)
                    let formatter = DateFormatter()
                    formatter.dateStyle = .none
                    formatter.timeStyle = .medium

                    let sunriseTime = formatter.string(from: sunriseDate)
                        print( "Sunrise: \(sunriseTime)")
                        
                        if let sunset = sysDictionary!["sunset"] as? NSNumber {
                            let sunsetDate = Date(timeIntervalSince1970: sunset.doubleValue)
                            let sunsetTime = formatter.string(from: sunsetDate)
                            
                            detailsEntity.setValue(sunriseTime, forKey: "sunrise")
                            detailsEntity.setValue(sunsetTime, forKey: "sunset")
                        }

                    }
                    //wind, speed
                    if let wind = json["wind"] as? [String:Any]{
                       if let speed = wind["speed"] {
                            detailsEntity.setValue("\(speed)", forKey: "wind")
                        }
                    }
                    //humidity , pressure, feel like
                    if let mainDict = json["main"] as? [String:Any]{
                        if let humidity = mainDict["humidity"]{
                            detailsEntity.setValue("\(humidity)", forKey: "humidity")
                        }
                        if let pressure = mainDict["pressure"]{
                            detailsEntity.setValue("\(pressure)", forKey: "pressure")
                        }
                        if let fellsLike = mainDict["feels_like"]{
                            detailsEntity.setValue("\(fellsLike)", forKey: "feelslike")
                        }
                        if let temp = mainDict["temp"] {
                            detailsEntity.setValue("\(temp)", forKey: "temp")
                        }
                        
                    }
    
                    do {
                        try self.context.save()
                        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Details")
                        
                        do {
                            let results = try self.context.fetch(fetchRequest)
                            let obtainedResults = results as! [NSManagedObject]
                            self.citiesData = obtainedResults
                        }catch{
                            print("Error")
                        }
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    }
    
                    catch{
                        print("There was an error in saving data")
                    }
                case .none:
                    break
                case .some(_):
                    break
                }
                //print(json)
                
            }
            catch let error as NSError {
                print(error.debugDescription)
            }

                
            
           }
           task.resume()

           
       }
    
    
}


