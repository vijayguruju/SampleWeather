//
//  WeatherDetailsTableViewCell.swift
//  SampleWeather
//
//  Created by Dinesh Sunder on 15/04/20.
//  Copyright © 2020 Vijay. All rights reserved.
//

import UIKit

class WeatherDetailsTableViewCell: UITableViewCell {
    @IBOutlet weak var sunriseLbl: UILabel!
    @IBOutlet weak var sunsetLbl: UILabel!
    @IBOutlet weak var humidityLbl: UILabel!
    @IBOutlet weak var feelsLikeLbl: UILabel!
    
    @IBOutlet weak var windLbl: UILabel!
    
    @IBOutlet weak var pressureLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
