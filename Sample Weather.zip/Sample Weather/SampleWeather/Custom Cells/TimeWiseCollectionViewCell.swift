//
//  TimeWiseCollectionViewCell.swift
//  SampleWeather
//
//  Created by Dinesh Sunder on 14/04/20.
//  Copyright © 2020 Vijay. All rights reserved.
//

import UIKit

class TimeWiseCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var tempLbl: UILabel!
    
    
}
